{
    "configured" : true,
    "active_rules" : {
        "classtypes": [ 
            "attempted-admin",
            "attempted-user",
            "inappropriate-content",
            "policy-violation",
            "shellcode-detect",
            "successful-admin",
            "successful-user",
            "trojan-activity",
            "unsuccessful-user",
            "web-application-attack"
        ],
        "categories": [ 
        ]
    }
}
